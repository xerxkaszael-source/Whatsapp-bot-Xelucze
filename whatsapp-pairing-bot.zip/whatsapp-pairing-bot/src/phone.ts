import { BotError } from './state.js';

const PHONE_INPUT_CHARS = /^[+\d\s()\-]+$/;

export function normalizePhoneNumber(input: unknown): string {
  if (typeof input !== 'string' || input.trim().length === 0) {
    throw new BotError('Enter an international phone number.', 'PHONE_REQUIRED');
  }

  if (input.length > 40 || !PHONE_INPUT_CHARS.test(input)) {
    throw new BotError(
      'Use an international number with digits, an optional leading +, spaces, hyphens, or parentheses only.',
      'PHONE_FORMAT',
    );
  }

  const normalized = input.replace(/[\s()\-]/g, '').replace(/^\+/, '');
  if (!/^\d{8,15}$/.test(normalized) || normalized.startsWith('0')) {
    throw new BotError(
      'Enter a valid international phone number with 8 to 15 digits, including its country code.',
      'PHONE_INVALID',
    );
  }

  return normalized;
}

export function maskPhoneNumber(phoneNumber: string): string {
  if (phoneNumber.length <= 6) return '****';
  return `${phoneNumber.slice(0, 3)}****${phoneNumber.slice(-3)}`;
}

import 'dotenv/config';
import { createServer } from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import { Server } from 'socket.io';
import { createAccessControl } from './access.js';
import { createApiRouter } from './api.js';
import { logger } from './logger.js';
import { WhatsAppManager } from './whatsapp.js';

const projectDirectory = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const publicDirectory = path.join(projectDirectory, 'public');
const sessionsDirectory = path.join(projectDirectory, 'sessions');
const port = Number(process.env.PORT ?? 3000);
const host = process.env.HOST ?? '0.0.0.0';

if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error('PORT must be a valid TCP port number.');
}

// Baileys credentials must be created with owner-only permissions.
process.umask(0o077);

const manager = new WhatsAppManager(sessionsDirectory);
const access = createAccessControl(process.env.ACCESS_PASSWORD);
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  maxHttpBufferSize: 16_000,
  allowRequest: (request, callback) => {
    const origin = request.headers.origin;
    let sameOrigin = true;
    try {
      if (origin) sameOrigin = new URL(origin).host === request.headers.host;
    } catch {
      sameOrigin = false;
    }
    callback(null, sameOrigin && access.isAuthorized(request));
  },
});

app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'", 'ws:', 'wss:'],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"],
    },
  },
}));
app.use(express.json({ limit: '4kb', strict: true }));
app.use('/api', access.router);
app.use('/api', access.middleware);
app.use('/api', createApiRouter(manager, io));
app.use(express.static(publicDirectory, {
  dotfiles: 'deny',
  index: 'index.html',
  maxAge: '1h',
  setHeaders: (response) => response.setHeader('Cache-Control', 'no-cache'),
}));
app.use((_request, response) => response.status(404).json({ error: 'Not found.' }));

io.on('connection', (socket) => {
  socket.emit('whatsapp:state', manager.getStatus());
});

manager.on('state', (state) => {
  io.emit('whatsapp:state', state);
  const eventByStatus: Record<string, string> = {
    CONNECTING: 'whatsapp:connecting',
    CONNECTED: 'whatsapp:connected',
    DISCONNECTED: 'whatsapp:disconnected',
    ERROR: 'whatsapp:error',
  };
  const event = eventByStatus[state.status];
  if (event) io.emit(event, state);
});

async function start(): Promise<void> {
  await manager.startFromSavedSession();
  await new Promise<void>((resolve, reject) => {
    httpServer.once('error', reject);
    httpServer.listen(port, host, () => {
      httpServer.off('error', reject);
      resolve();
    });
  });
  logger.info({ host, port }, 'WhatsApp bot web server is ready');
}

let shuttingDown = false;
async function shutdown(signal: string): Promise<void> {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info({ signal }, 'Shutting down WhatsApp bot');
  await manager.shutdown();
  io.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 5_000).unref();
}

process.once('SIGINT', () => void shutdown('SIGINT'));
process.once('SIGTERM', () => void shutdown('SIGTERM'));

void start().catch((error: unknown) => {
  logger.error({ error: error instanceof Error ? error.message : String(error) }, 'Server failed to start');
  process.exitCode = 1;
});

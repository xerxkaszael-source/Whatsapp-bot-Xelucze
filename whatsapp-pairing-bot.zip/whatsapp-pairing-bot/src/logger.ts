import pino from 'pino';

export const logger = pino({
  level: process.env.LOG_LEVEL ?? 'info',
  timestamp: pino.stdTimeFunctions.isoTime,
  redact: {
    paths: [
      'pairingCode',
      '*.pairingCode',
      'creds',
      '*.creds',
      'authState',
      '*.authState',
      'keys',
      '*.keys',
      'token',
      '*.token',
      'access_token',
      'password',
    ],
    censor: '[REDACTED]',
  },
});

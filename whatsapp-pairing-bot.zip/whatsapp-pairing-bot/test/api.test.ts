import test from 'node:test';
import assert from 'node:assert/strict';
import express from 'express';
import { createServer } from 'node:http';
import { Server } from 'socket.io';
import request from 'supertest';
import { createApiRouter } from '../src/api.js';
import type { PublicStatus } from '../src/state.js';

async function makeApp() {
  const sent: Array<{ event: string; payload: unknown }> = [];
  const expectedCode = 'ABCD1234';
  const status: PublicStatus = {
    status: 'IDLE',
    message: 'Enter your WhatsApp number.',
    updatedAt: new Date(0).toISOString(),
  };
  const manager = {
    async requestPairingCode(phoneNumber: string) {
      assert.equal(phoneNumber, '6281249584893');
      return expectedCode;
    },
    getStatus() { return status; },
  };
  const app = express();
  app.use(express.json());
  const server = createServer(app);
  const io = new Server(server);
  // In unit tests the socket recipient is known; no WhatsApp request is made.
  io.sockets.sockets.set('test-socket-id', {} as never);
  const originalTo = io.to.bind(io);
  io.to = ((room: string) => ({
    emit(event: string, payload: unknown) {
      if (room === 'test-socket-id') sent.push({ event, payload });
      return true;
    },
  }) as never) as typeof io.to;
  void originalTo;
  app.use('/api', createApiRouter(manager, io));
  return { app, server, io, sent, expectedCode };
}

test('status endpoint exposes only public state and disables caching', async () => {
  const context = await makeApp();
  const response = await request(context.app).get('/api/status').expect(200);
  assert.equal(response.headers['cache-control'], 'no-store');
  assert.equal(response.body.status, 'IDLE');
  assert.equal('creds' in response.body, false);
  assert.equal('pairingCode' in response.body, false);
  await new Promise<void>((resolve) => context.io.close(() => resolve()));
});

test('pair endpoint passes through the manager code unchanged and targets the requesting socket', async () => {
  const context = await makeApp();
  const response = await request(context.app)
    .post('/api/pair')
    .send({ phoneNumber: '+62 812-4958-4893', socketId: 'test-socket-id' })
    .expect(200);
  assert.equal(response.body.pairingCode, context.expectedCode);
  assert.ok(context.sent.some(({ event, payload }) => event === 'pairing:code' && (payload as { pairingCode: string }).pairingCode === context.expectedCode));
  await new Promise<void>((resolve) => context.io.close(() => resolve()));
});

test('pair endpoint rejects malformed phone input with a useful response', async () => {
  const context = await makeApp();
  const response = await request(context.app)
    .post('/api/pair')
    .send({ phoneNumber: '0812345678', socketId: 'test-socket-id' })
    .expect(400);
  assert.equal(response.body.success, false);
  assert.match(response.body.error, /international phone number/i);
  await new Promise<void>((resolve) => context.io.close(() => resolve()));
});

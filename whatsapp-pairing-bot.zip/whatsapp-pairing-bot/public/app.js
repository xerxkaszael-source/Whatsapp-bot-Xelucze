(() => {
  const accessGate = document.querySelector('#access-gate');
  const accessForm = document.querySelector('#access-form');
  const accessPassword = document.querySelector('#access-password');
  const accessError = document.querySelector('#access-error');
  const botCard = document.querySelector('#bot-card');
  const form = document.querySelector('#pair-form');
  const phoneInput = document.querySelector('#phone-number');
  const connectButton = document.querySelector('#connect-button');
  const newCodeButton = document.querySelector('#new-code-button');
  const pairingPanel = document.querySelector('#pairing-panel');
  const pairingCode = document.querySelector('#pairing-code');
  const codeCaption = document.querySelector('.code-caption');
  const statusMessage = document.querySelector('#status-message');
  const statusDot = document.querySelector('#status-dot');
  const connectedPhone = document.querySelector('#connected-phone');
  const errorMessage = document.querySelector('#error-message');
  const socket = io({ autoConnect: false });
  let busy = false;
  let appStarted = false;

  function setBusy(value) {
    busy = value;
    connectButton.disabled = value;
    newCodeButton.disabled = value;
    connectButton.querySelector('span:first-child').textContent = value ? 'Requesting code…' : 'Connect WhatsApp';
  }

  function showError(message) {
    errorMessage.textContent = message;
    errorMessage.hidden = !message;
  }

  function showCode(code) {
    codeCaption.textContent = 'Enter this exact code in WhatsApp:';
    pairingCode.textContent = code;
    pairingPanel.hidden = false;
    showError('');
  }

  function showCodeRecovery(message) {
    codeCaption.textContent = message;
    pairingCode.textContent = '—';
    pairingPanel.hidden = false;
  }

  function renderState(state) {
    if (!state || typeof state.status !== 'string') return;
    statusMessage.textContent = state.message || 'Waiting for WhatsApp…';
    statusDot.dataset.state = state.status === 'CONNECTED'
      ? 'connected'
      : ['ERROR', 'DISCONNECTED'].includes(state.status)
        ? 'error'
        : state.status === 'IDLE'
          ? ''
          : 'active';
    connectedPhone.hidden = state.status !== 'CONNECTED' || !state.phoneNumber;
    connectedPhone.textContent = state.phoneNumber ? `Phone: ${state.phoneNumber}` : '';
    if (state.status === 'CONNECTED') {
      pairingPanel.hidden = true;
      pairingCode.textContent = '';
      showError('');
      setBusy(false);
    } else if (state.status === 'WAITING_FOR_USER' && !pairingCode.textContent) {
      showCodeRecovery('The active code is only available in the tab that requested it. Request a fresh code here if needed.');
    } else if (state.status === 'ERROR' || state.status === 'DISCONNECTED') {
      if (!pairingPanel.hidden) {
        showCodeRecovery('The previous code may no longer work. Request a fresh code to continue.');
      }
      setBusy(false);
    }
  }

  async function requestPairingCode(forceNew) {
    if (busy) return;
    if (!socket.connected) {
      showError('The live connection is not ready yet. Wait a moment and try again.');
      return;
    }
    setBusy(true);
    showError('');
    pairingPanel.hidden = true;
    pairingCode.textContent = '';
    try {
      const response = await fetch('/api/pair', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        cache: 'no-store',
        body: JSON.stringify({ phoneNumber: phoneInput.value, socketId: socket.id, forceNew }),
      });
      const result = await response.json();
      if (!response.ok || !result.success) throw new Error(result.error || 'Pairing request failed.');
      showCode(result.pairingCode);
      setBusy(false);
    } catch (error) {
      showError(error instanceof Error ? error.message : 'Unable to request a pairing code.');
      setBusy(false);
    }
  }

  function startApp() {
    if (appStarted) return;
    appStarted = true;
    accessGate.hidden = true;
    botCard.hidden = false;
    socket.connect();

    socket.on('whatsapp:state', renderState);
    socket.on('pairing:code', (payload) => {
      if (typeof payload?.pairingCode === 'string') showCode(payload.pairingCode);
    });
    socket.on('whatsapp:connected', renderState);
    socket.on('whatsapp:disconnected', renderState);
    socket.on('whatsapp:error', (payload) => {
      if (payload?.message) showError(payload.message);
      setBusy(false);
    });
    socket.on('connect', () => showError(''));
    socket.on('connect_error', () => {
      showError('Live updates could not connect. Check the server and refresh the page.');
      setBusy(false);
    });

    fetch('/api/status', { cache: 'no-store' })
      .then((response) => {
        if (response.status === 401) throw new Error('Access expired. Refresh the page and enter the password again.');
        return response.json();
      })
      .then(renderState)
      .catch((error) => {
        statusMessage.textContent = error instanceof Error ? error.message : 'Could not read connection status.';
      });
  }

  accessForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    accessError.hidden = true;
    const button = accessForm.querySelector('button');
    button.disabled = true;
    try {
      const response = await fetch('/api/access', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        cache: 'no-store',
        body: JSON.stringify({ password: accessPassword.value }),
      });
      const result = await response.json();
      if (!response.ok || !result.success) throw new Error(result.error || 'Access denied.');
      accessPassword.value = '';
      startApp();
    } catch (error) {
      accessError.textContent = error instanceof Error ? error.message : 'Could not verify access.';
      accessError.hidden = false;
      accessPassword.focus();
    } finally {
      button.disabled = false;
    }
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    void requestPairingCode(false);
  });
  newCodeButton.addEventListener('click', () => void requestPairingCode(true));

  fetch('/api/access', { cache: 'no-store' })
    .then((response) => response.json())
    .then((access) => {
      if (access.required && !access.authorized) {
        accessGate.hidden = false;
        accessPassword.focus();
      } else {
        startApp();
      }
    })
    .catch(() => {
      accessGate.hidden = false;
      accessError.textContent = 'Could not check access. Refresh the page and try again.';
      accessError.hidden = false;
    });
})();

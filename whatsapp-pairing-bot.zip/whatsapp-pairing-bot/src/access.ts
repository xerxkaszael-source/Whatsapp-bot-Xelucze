import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import type { IncomingMessage } from 'node:http';
import { Router, type RequestHandler } from 'express';
import rateLimit from 'express-rate-limit';

const COOKIE_NAME = 'wa_bot_access';
const COOKIE_MAX_AGE_SECONDS = 6 * 60 * 60;

export interface AccessControl {
  router: Router;
  middleware: RequestHandler;
  isAuthorized(request: IncomingMessage): boolean;
}

function constantTimeStringEqual(left: string, right: string): boolean {
  const leftHash = createHash('sha256').update(left).digest();
  const rightHash = createHash('sha256').update(right).digest();
  return timingSafeEqual(leftHash, rightHash);
}

export function createAccessControl(password: string | undefined): AccessControl {
  const required = Boolean(password);
  if (required && password!.length < 16) {
    throw new Error('ACCESS_PASSWORD must contain at least 16 characters when access protection is enabled.');
  }
  const cookieValue = randomBytes(32).toString('base64url');

  function isAuthorized(request: IncomingMessage): boolean {
    if (!required) return true;
    const rawCookie = request.headers.cookie;
    const cookieHeader = Array.isArray(rawCookie) ? rawCookie.join(';') : rawCookie ?? '';
    const prefix = `${COOKIE_NAME}=`;
    const entry = cookieHeader.split(';').map((part) => part.trim()).find((part) => part.startsWith(prefix));
    if (!entry) return false;
    const value = entry.slice(prefix.length);
    try {
      return constantTimeStringEqual(decodeURIComponent(value), cookieValue);
    } catch {
      return false;
    }
  }

  const router = Router();
  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 5,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { success: false, error: 'Too many access attempts. Wait 15 minutes and try again.' },
  });

  router.get('/access', (request, response) => {
    response.setHeader('Cache-Control', 'no-store');
    response.json({ required, authorized: isAuthorized(request) });
  });

  router.post('/access', loginLimiter, (request, response) => {
    if (!required) {
      response.json({ success: true });
      return;
    }

    const submitted = request.body?.password;
    if (typeof submitted !== 'string' || !constantTimeStringEqual(submitted, password!)) {
      response.status(401).json({ success: false, error: 'Access password is incorrect.' });
      return;
    }

    response.cookie(COOKIE_NAME, cookieValue, {
      httpOnly: true,
      sameSite: 'strict',
      secure: request.secure || request.get('x-forwarded-proto') === 'https',
      maxAge: COOKIE_MAX_AGE_SECONDS * 1000,
      path: '/',
    });
    response.setHeader('Cache-Control', 'no-store');
    response.json({ success: true });
  });

  const middleware: RequestHandler = (request, response, next) => {
    if (isAuthorized(request)) {
      next();
      return;
    }
    response.status(401).setHeader('Cache-Control', 'no-store');
    response.json({ success: false, error: 'Enter the temporary access password to continue.' });
  };

  return { router, middleware, isAuthorized };
}

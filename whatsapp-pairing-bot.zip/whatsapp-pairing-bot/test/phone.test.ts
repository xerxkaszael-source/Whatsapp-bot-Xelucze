import test from 'node:test';
import assert from 'node:assert/strict';
import { maskPhoneNumber, normalizePhoneNumber } from '../src/phone.js';
import { BotError } from '../src/state.js';

test('normalizes international phone numbers without changing country code', () => {
  assert.equal(normalizePhoneNumber('+62 812-4958-4893'), '6281249584893');
  assert.equal(normalizePhoneNumber('44727627488'), '44727627488');
  assert.equal(normalizePhoneNumber('(44) 7276 27488'), '44727627488');
});

test('rejects missing, local, malformed, and out-of-range numbers', () => {
  for (const value of [undefined, '', '0812345678', '+62.812.4958.4893', '1234567', '1234567890123456']) {
    assert.throws(() => normalizePhoneNumber(value), BotError);
  }
});

test('masks phone numbers for structured logs', () => {
  assert.equal(maskPhoneNumber('6281249584893'), '628****893');
});

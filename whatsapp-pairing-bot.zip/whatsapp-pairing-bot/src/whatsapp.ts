import { EventEmitter } from 'node:events';
import { chmod, mkdir, rm } from 'node:fs/promises';
import path from 'node:path';
import pino from 'pino';
import makeWASocket, {
  Browsers,
  DisconnectReason,
  useMultiFileAuthState,
  type WASocket,
  type WAMessage,
  proto,
} from '@whiskeysockets/baileys';
import { logger } from './logger.js';
import { maskPhoneNumber } from './phone.js';
import { BotError, type BotStatus, type PublicStatus } from './state.js';

type AuthStateResult = Awaited<ReturnType<typeof useMultiFileAuthState>>;

const MAX_RECONNECT_ATTEMPTS = 5;
const PAIRING_TIMEOUT_MS = 30_000;
const SOCKET_OPEN_TIMEOUT_MS = 20_000;
const SEEN_MESSAGE_LIMIT = 2_000;

function statusCodeOf(error: unknown): number | undefined {
  if (typeof error !== 'object' || error === null || !('output' in error)) return undefined;
  const output = (error as { output?: unknown }).output;
  if (typeof output !== 'object' || output === null || !('statusCode' in output)) return undefined;
  const value = (output as { statusCode?: unknown }).statusCode;
  return typeof value === 'number' ? value : undefined;
}

function phoneFromAuth(auth: AuthStateResult['state']): string | undefined {
  const id = auth.creds.me?.id;
  if (!id) return undefined;
  return id.split('@')[0]?.split(':')[0];
}

function withTimeout<T>(promise: Promise<T>, milliseconds: number, message: string): Promise<T> {
  let timer: NodeJS.Timeout | undefined;
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => {
      timer = setTimeout(() => reject(new BotError(message, 'TIMEOUT')), milliseconds);
    }),
  ]).finally(() => {
    if (timer) clearTimeout(timer);
  });
}

function unwrapMessage(message: proto.IMessage | null | undefined): proto.IMessage | undefined {
  let current = message ?? undefined;
  for (let i = 0; i < 5 && current; i += 1) {
    const nested = current.ephemeralMessage?.message
      ?? current.viewOnceMessage?.message
      ?? current.viewOnceMessageV2?.message
      ?? current.viewOnceMessageV2Extension?.message
      ?? current.documentWithCaptionMessage?.message;
    if (!nested) break;
    current = nested;
  }
  return current;
}

function extractText(message: WAMessage): string | undefined {
  const content = unwrapMessage(message.message);
  return content?.conversation
    ?? content?.extendedTextMessage?.text
    ?? content?.imageMessage?.caption
    ?? content?.videoMessage?.caption
    ?? content?.documentMessage?.caption
    ?? undefined;
}

export class WhatsAppManager extends EventEmitter {
  private socket: WASocket | undefined;
  private auth: AuthStateResult | undefined;
  private activePhone: string | undefined;
  private pairingCode: string | undefined;
  private pairingInProgress = false;
  private reconnectAttempts = 0;
  private reconnectTimer: NodeJS.Timeout | undefined;
  private stopping = false;
  private readonly intentionallyClosed = new WeakSet<WASocket>();
  private readonly seenMessageIds = new Set<string>();
  private status: PublicStatus = {
    status: 'IDLE',
    message: 'Enter your WhatsApp number.',
    updatedAt: new Date().toISOString(),
  };

  constructor(private readonly sessionDirectory: string) {
    super();
  }

  getStatus(): PublicStatus {
    return { ...this.status };
  }

  private setStatus(status: BotStatus, message: string, phoneNumber = this.activePhone): void {
    this.status = {
      status,
      ...(phoneNumber ? { phoneNumber } : {}),
      message,
      updatedAt: new Date().toISOString(),
    };
    this.emit('state', this.getStatus());
  }

  async startFromSavedSession(): Promise<void> {
    await mkdir(this.sessionDirectory, { recursive: true, mode: 0o700 });
    await chmod(this.sessionDirectory, 0o700);

    try {
      const auth = await useMultiFileAuthState(this.sessionDirectory);
      this.auth = auth;
      if (!auth.state.creds.registered) {
        auth.state.creds.pairingCode = undefined;
        await auth.saveCreds();
        this.setStatus('IDLE', 'Enter your WhatsApp number.');
        return;
      }

      this.activePhone = phoneFromAuth(auth.state);
      auth.state.creds.pairingCode = undefined;
      await auth.saveCreds();
      logger.info({ phone: this.activePhone ? maskPhoneNumber(this.activePhone) : undefined }, '[WhatsApp] Initializing saved session');
      this.setStatus('CONNECTING', 'Reconnecting to your saved WhatsApp session.');
      this.createSocket(auth);
    } catch (error) {
      logger.error({ error: error instanceof Error ? error.message : String(error) }, '[WhatsApp] Saved session initialization failed');
      this.setStatus('ERROR', 'The saved WhatsApp session could not be loaded. Check the session folder, then restart.');
    }
  }

  async requestPairingCode(phoneNumber: string, forceNew = false): Promise<string> {
    if (this.pairingInProgress) {
      throw new BotError('A pairing request is already being processed. Please wait.', 'PAIRING_IN_PROGRESS');
    }
    if (this.status.status === 'CONNECTED') {
      throw new BotError('WhatsApp is already connected.', 'ALREADY_CONNECTED');
    }
    if (this.auth?.state.creds.registered) {
      throw new BotError('A saved WhatsApp session is reconnecting. Wait for its connection status before pairing again.', 'SESSION_EXISTS');
    }
    if (this.pairingCode && !forceNew) {
      throw new BotError('A pairing code is already active. If it expired, choose “Request a new code”.', 'CODE_ACTIVE');
    }

    this.pairingInProgress = true;
    try {
      const previousUnregisteredAttempt = this.status.status === 'ERROR'
        || (this.status.status === 'DISCONNECTED' && !this.auth?.state.creds.registered);
      if (forceNew || this.socket || this.pairingCode || previousUnregisteredAttempt) {
        await this.resetPendingSession();
      }

      this.activePhone = phoneNumber;
      this.pairingCode = undefined;
      this.setStatus('PAIRING_REQUESTED', 'Requesting a pairing code from WhatsApp.');
      logger.info({ phone: maskPhoneNumber(phoneNumber) }, '[WhatsApp] Initializing pairing session');

      await mkdir(this.sessionDirectory, { recursive: true, mode: 0o700 });
      await chmod(this.sessionDirectory, 0o700);
      const auth = await useMultiFileAuthState(this.sessionDirectory);
      this.auth = auth;
      if (auth.state.creds.registered) {
        throw new BotError('A saved WhatsApp session already exists. Restart the server to reconnect it.', 'SESSION_EXISTS');
      }

      const socket = this.createSocket(auth);
      logger.info({ phone: maskPhoneNumber(phoneNumber) }, '[WhatsApp] Requesting pairing code');
      await withTimeout(socket.waitForSocketOpen(), SOCKET_OPEN_TIMEOUT_MS, 'Timed out connecting to WhatsApp. Please try again.');
      const code = await withTimeout(
        socket.requestPairingCode(phoneNumber),
        PAIRING_TIMEOUT_MS,
        'WhatsApp did not return a pairing code in time. Please request a new code.',
      );

      if (typeof code !== 'string' || code.length === 0) {
        throw new Error('Baileys returned an empty pairing code.');
      }
      this.pairingCode = code;
      this.setStatus('PAIRING_CODE_READY', 'Your pairing code is ready. Enter it in WhatsApp.');
      logger.info({ phone: maskPhoneNumber(phoneNumber) }, '[WhatsApp] Pairing code generated');
      this.setStatus('WAITING_FOR_USER', 'Enter the pairing code in WhatsApp to finish linking.');
      logger.info({ phone: maskPhoneNumber(phoneNumber) }, '[WhatsApp] Waiting for user');
      return code;
    } catch (error) {
      logger.error({ error: error instanceof Error ? error.message : String(error), phone: maskPhoneNumber(phoneNumber) }, '[WhatsApp] Pairing request failed');
      if (!this.auth?.state.creds.registered) {
        await this.closeSocket();
      }
      const message = error instanceof BotError
        ? error.message
        : 'Unable to request a WhatsApp pairing code. Check the phone number and try again.';
      this.pairingCode = undefined;
      this.setStatus('ERROR', message);
      throw new BotError(message, error instanceof BotError ? error.code : 'PAIRING_FAILED');
    } finally {
      this.pairingInProgress = false;
    }
  }

  private createSocket(auth: AuthStateResult): WASocket {
    if (this.socket) return this.socket;

    const socket = makeWASocket({
      auth: auth.state,
      logger: pino({ level: 'silent' }),
      browser: Browsers.ubuntu('Chrome'),
      markOnlineOnConnect: false,
      syncFullHistory: false,
      connectTimeoutMs: SOCKET_OPEN_TIMEOUT_MS,
      defaultQueryTimeoutMs: PAIRING_TIMEOUT_MS,
    });
    this.socket = socket;

    socket.ev.on('creds.update', async () => {
      try {
        if (auth.state.creds.registered) {
          auth.state.creds.pairingCode = undefined;
          this.pairingCode = undefined;
        }
        await auth.saveCreds();
      } catch (error) {
        logger.error({ error: error instanceof Error ? error.message : String(error) }, '[WhatsApp] Failed to persist authentication state');
      }
    });

    socket.ev.on('connection.update', (update) => {
      void this.handleConnectionUpdate(socket, auth, update.connection, update.lastDisconnect?.error);
    });

    socket.ev.on('messages.upsert', async ({ messages, type }) => {
      if (type !== 'notify') return;
      for (const message of messages) {
        await this.handleMessage(socket, message);
      }
    });

    return socket;
  }

  private async handleConnectionUpdate(
    socket: WASocket,
    auth: AuthStateResult,
    connection: 'open' | 'connecting' | 'close' | undefined,
    error: unknown,
  ): Promise<void> {
    if (this.intentionallyClosed.has(socket) || this.stopping || this.socket !== socket) return;

    if (connection === 'connecting') {
      if (auth.state.creds.registered) this.setStatus('CONNECTING', 'Connecting to WhatsApp.');
      return;
    }

    if (connection === 'open') {
      this.reconnectAttempts = 0;
      this.activePhone = phoneFromAuth(auth.state) ?? this.activePhone;
      auth.state.creds.pairingCode = undefined;
      this.pairingCode = undefined;
      try {
        await auth.saveCreds();
      } catch (saveError) {
        logger.error({ error: saveError instanceof Error ? saveError.message : String(saveError) }, '[WhatsApp] Failed to save credentials after connection');
      }
      logger.info({ phone: this.activePhone ? maskPhoneNumber(this.activePhone) : undefined }, '[WhatsApp] Connected');
      this.setStatus('CONNECTED', 'WhatsApp is connected. The bot is ready.');
      return;
    }

    if (connection === 'close') {
      const code = statusCodeOf(error);
      logger.warn({ code, phone: this.activePhone ? maskPhoneNumber(this.activePhone) : undefined }, '[WhatsApp] Connection closed');
      this.socket = undefined;
      const shouldResumeRegistration = code === DisconnectReason.restartRequired && Boolean(auth.state.creds.me?.id);
      const hasRegisteredSession = auth.state.creds.registered;
      if ((shouldResumeRegistration || hasRegisteredSession) && this.reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        this.setStatus('DISCONNECTED', 'WhatsApp disconnected. Reconnecting safely…');
        this.scheduleReconnect(auth);
        return;
      }

      this.pairingCode = undefined;
      this.setStatus(
        hasRegisteredSession ? 'DISCONNECTED' : 'ERROR',
        hasRegisteredSession
          ? 'WhatsApp disconnected. The saved session can reconnect when the server restarts.'
          : 'The pairing connection ended. Request a new pairing code and try again.',
      );
    }
  }

  private scheduleReconnect(auth: AuthStateResult): void {
    if (this.reconnectTimer || this.stopping || this.socket) return;
    this.reconnectAttempts += 1;
    const delayMs = Math.min(1_000 * 2 ** (this.reconnectAttempts - 1), 16_000);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = undefined;
      if (this.stopping || this.socket) return;
      this.setStatus('CONNECTING', 'Reconnecting to WhatsApp.');
      try {
        this.createSocket(auth);
      } catch (error) {
        logger.error({ error: error instanceof Error ? error.message : String(error), attempt: this.reconnectAttempts }, '[WhatsApp] Reconnect attempt failed');
        if (this.reconnectAttempts < MAX_RECONNECT_ATTEMPTS) this.scheduleReconnect(auth);
        else this.setStatus('ERROR', 'WhatsApp could not reconnect after several attempts. Restart the server to try again.');
      }
    }, delayMs);
  }

  private async resetPendingSession(): Promise<void> {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = undefined;
    }
    await this.closeSocket();
    this.pairingCode = undefined;
    this.auth = undefined;
    await rm(this.sessionDirectory, { recursive: true, force: true });
    await mkdir(this.sessionDirectory, { recursive: true, mode: 0o700 });
    await chmod(this.sessionDirectory, 0o700);
  }

  private async closeSocket(): Promise<void> {
    const socket = this.socket;
    if (!socket) return;
    this.intentionallyClosed.add(socket);
    this.socket = undefined;
    try {
      socket.end(new Error('Pairing attempt closed by the application'));
    } catch {
      // A socket may already have closed; auth state remains on disk for the next attempt.
    }
  }

  private async handleMessage(socket: WASocket, message: WAMessage): Promise<void> {
    if (socket !== this.socket || message.key.fromMe) return;
    const jid = message.key.remoteJid;
    if (!jid || jid === 'status@broadcast') return;
    const id = message.key.id;
    if (id && this.seenMessageIds.has(id)) return;
    if (id) {
      this.seenMessageIds.add(id);
      if (this.seenMessageIds.size > SEEN_MESSAGE_LIMIT) {
        const oldest = this.seenMessageIds.values().next().value as string | undefined;
        if (oldest) this.seenMessageIds.delete(oldest);
      }
    }

    const text = extractText(message);
    if (!text) return;
    const command = text.trim().toLowerCase();
    const replies: Record<string, string> = {
      ping: 'pong',
      hello: 'Hello! WhatsApp bot is connected.',
      help: 'Available commands:\nping\nhello\nhelp',
    };
    const reply = replies[command];
    if (!reply) return;

    const sender = message.key.participant ?? jid;
    logger.info({ sender, messageId: id, timestamp: message.messageTimestamp }, '[WhatsApp] Message received');
    try {
      await socket.sendMessage(jid, { text: reply }, { quoted: message });
    } catch (error) {
      logger.error({ messageId: id, error: error instanceof Error ? error.message : String(error) }, '[WhatsApp] Failed to send bot reply');
    }
  }

  async shutdown(): Promise<void> {
    this.stopping = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = undefined;
    await this.closeSocket();
  }
}

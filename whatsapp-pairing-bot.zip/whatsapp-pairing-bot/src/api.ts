import { Router, type Request } from 'express';
import rateLimit from 'express-rate-limit';
import type { Server } from 'socket.io';
import { normalizePhoneNumber } from './phone.js';
import { BotError, type PublicStatus } from './state.js';

export interface PairingManager {
  requestPairingCode(phoneNumber: string, forceNew?: boolean): Promise<string>;
  getStatus(): PublicStatus;
}

function isSameOrigin(request: Request): boolean {
  const origin = request.get('origin');
  if (!origin) return true;
  try {
    return new URL(origin).host === request.get('host');
  } catch {
    return false;
  }
}

export function createApiRouter(manager: PairingManager, io: Server): Router {
  const router = Router();
  const pairLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 4,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { success: false, error: 'Too many pairing requests. Please wait 15 minutes before trying again.' },
  });

  router.get('/status', (_request, response) => {
    response.setHeader('Cache-Control', 'no-store');
    response.json(manager.getStatus());
  });

  router.post('/pair', pairLimiter, async (request, response) => {
    if (!isSameOrigin(request)) {
      response.status(403).json({ success: false, error: 'Pairing requests must come from this website.' });
      return;
    }

    const socketId = request.body?.socketId;
    const forceNew = request.body?.forceNew === true;
    if (typeof socketId !== 'string' || socketId.length < 8 || !io.sockets.sockets.has(socketId)) {
      response.status(400).json({ success: false, error: 'Refresh the page and try connecting again.' });
      return;
    }

    let phoneNumber: string;
    try {
      phoneNumber = normalizePhoneNumber(request.body?.phoneNumber);
    } catch (error) {
      const message = error instanceof BotError ? error.message : 'Enter a valid international phone number.';
      response.status(400).json({ success: false, error: message });
      return;
    }

    io.to(socketId).emit('pairing:requested', { phoneNumber });
    try {
      const pairingCode = await manager.requestPairingCode(phoneNumber, forceNew);
      io.to(socketId).emit('pairing:code', { phoneNumber, pairingCode });
      io.to(socketId).emit('pairing:waiting', { phoneNumber });
      response.setHeader('Cache-Control', 'no-store');
      response.json({ success: true, status: 'PAIRING_CODE_READY', pairingCode });
    } catch (error) {
      const message = error instanceof BotError
        ? error.message
        : 'Unable to request a WhatsApp pairing code. Check the phone number and try again.';
      const status = error instanceof BotError && error.code === 'PAIRING_IN_PROGRESS' ? 409 : 400;
      io.to(socketId).emit('whatsapp:error', { message });
      response.status(status).json({ success: false, error: message });
    }
  });

  return router;
}

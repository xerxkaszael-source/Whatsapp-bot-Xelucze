import test from 'node:test';
import assert from 'node:assert/strict';
import express from 'express';
import request from 'supertest';
import { createAccessControl } from '../src/access.js';

const TEST_PASSWORD = 'test-password-with-more-than-16-chars';

test('temporary access password gates protected requests until an HttpOnly cookie is issued', async () => {
  const access = createAccessControl(TEST_PASSWORD);
  const app = express();
  app.use(express.json());
  app.use('/api', access.router);
  app.use('/api', access.middleware);
  app.get('/api/protected', (_request, response) => response.json({ ok: true }));

  const info = await request(app).get('/api/access').expect(200);
  assert.deepEqual(info.body, { required: true, authorized: false });
  await request(app).get('/api/protected').expect(401);
  await request(app).post('/api/access').send({ password: 'wrong password' }).expect(401);

  const login = await request(app).post('/api/access').send({ password: TEST_PASSWORD }).expect(200);
  const cookie = login.headers['set-cookie']?.[0];
  assert.ok(cookie?.includes('HttpOnly'));
  assert.ok(cookie?.includes('SameSite=Strict'));
  const protectedResponse = await request(app)
    .get('/api/protected')
    .set('Cookie', cookie!.split(';')[0]!)
    .expect(200);
  assert.equal(protectedResponse.body.ok, true);
});

test('access password must not be trivially short', () => {
  assert.throws(() => createAccessControl('short'), /at least 16 characters/i);
});

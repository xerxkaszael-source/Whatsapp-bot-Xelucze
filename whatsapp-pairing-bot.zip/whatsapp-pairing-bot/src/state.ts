export type BotStatus =
  | 'IDLE'
  | 'PAIRING_REQUESTED'
  | 'PAIRING_CODE_READY'
  | 'WAITING_FOR_USER'
  | 'CONNECTING'
  | 'CONNECTED'
  | 'DISCONNECTED'
  | 'ERROR';

export interface PublicStatus {
  status: BotStatus;
  phoneNumber?: string;
  message: string;
  updatedAt: string;
}

export class BotError extends Error {
  constructor(
    message: string,
    public readonly code: string,
  ) {
    super(message);
    this.name = 'BotError';
  }
}

# WhatsApp Pairing Bot

A small single-session WhatsApp bot built with Node.js, TypeScript, Express, Socket.IO, and **Baileys phone-number pairing**. The web interface accepts an international number, displays only the pairing code returned by Baileys, and updates connection state in real time. It has no QR-based login UI or fallback.

> Baileys is an unofficial WhatsApp Web client library, not an official WhatsApp Business API. Protocol changes or WhatsApp policy enforcement can interrupt operation or affect the linked account. Use an account you control and follow WhatsApp's terms.

## Requirements

- Node.js 20+ (tested with Node 22)
- A WhatsApp account/device you control
- Network access to WhatsApp Web services

## Install and run

```bash
npm install
cp .env.example .env
npm run build
npm start
```

Open `http://localhost:3000` (or the host/port configured in `.env`). For development with TypeScript watch mode:

```bash
npm run dev
```

## Pairing flow

1. Enter a full international number, including its country calling code. For example, `+62 812-4958-4893` is normalized to `6281249584893`.
2. Select **Connect WhatsApp**. The server creates one Baileys socket and calls `await sock.requestPairingCode(normalizedPhoneNumber)` from the installed Baileys 6.7.24 package.
3. The browser displays the exact string returned from that Baileys call; the app does not make or transform a code.
4. In WhatsApp, open **Settings → Linked Devices → Link a Device → Link with phone number instead**, then enter the displayed code.
5. When Baileys reports an open connection, the UI changes to **WhatsApp Connected** and the bot handles `ping`, `hello`, and `help`.

Pairing codes are sent only to the browser's connected Socket.IO client and returned to that same browser's no-store HTTP response. They are never written to logs. A pending code can be replaced with **Request a new code**. The server rate-limits pairing requests.

## API

- `POST /api/pair` accepts `{ "phoneNumber": "+62 812-4958-4893", "socketId": "...", "forceNew": false }` and returns the Baileys-generated code.
- `GET /api/status` returns the public connection state and connected phone number when available. Auth data is never returned.
- Socket.IO emits connection-state updates; the pairing code event is addressed only to the requesting browser.

## Session and security

- Baileys' `useMultiFileAuthState()` persists session data under `./sessions/` so a registered session can reconnect after a server restart.
- `sessions/` is excluded from Git and never served by Express. The process uses an owner-only umask and the session directory is mode `0700`.
- The temporary pairing code is cleared from saved credentials after registration/open and cleared when a new code is requested. Baileys may persist its internal in-progress pairing state while a pairing attempt is pending; restart clears an unregistered code before showing the pairing page.
- Only one WhatsApp session is supported. Reconnects are bounded rather than looping indefinitely.
- Before public testing, set `ACCESS_PASSWORD` to a long random value. The page asks for it, then issues an HttpOnly, SameSite cookie; both API and Socket.IO pairing access require that cookie. The cookie expires after six hours, and password attempts are rate-limited.
- An empty `ACCESS_PASSWORD` disables the gate for local-only development. Do not expose the app publicly without setting it. The gate is temporary-test access control, not a substitute for production user accounts or HTTPS.

## Validation and tests

```bash
npm test
npm run build
```

Tests cover number normalization, invalid input, and API behavior. A live WhatsApp pairing cannot be safely tested without a person entering the code on their own WhatsApp device; no account is paired automatically by this project.
